# CHECKPOINT — 17 février 2026 — Session soir

## PROJET
PDF "Lumières d'Israël — La Torah Vivante" (296 pages, 118 fiches, 4 templates).
Fichiers source : PULSIO100199.pdf (p.1-99), PULSIO200296.pdf (p.100-296).
Templates de calibrage : calibrage_canevas_1-4.html.
Checkpoint précédent : CHECKPOINT_2026-02-17.md

## TRAVAIL EFFECTUÉ — 21 FICHES PAGES DROITES CORRIGÉES

### Template 3 (Œuvres Majeures enrichies, Saviez-vous, Héritage)
Couleurs rouge #8A3230/#91413A (Codificateurs ch.13) :
1. **Rif** — p.196
2. **Méïri** — p.196 (même page)
3. **Rosh** — p.198
4. **Tour (Baal HaTourim)** — p.200
5. **Abravanel** — p.202
6. **Sforno** — p.204
7. **Karo** — p.206
8. **Rama** — p.208
9. **Maharal** — p.210
10. **Kli Yakar** — p.212

Couleurs vert #2C8B55/#389560 (Kabbale de Safed ch.14) :
11. **Or Ha'Haïm Hakadosh** — p.216
12. **Ramak** — p.218
13. **Ari Zal** — p.220
14. **Rabbi 'Haïm Vital** — p.222
15. **Ramhal** — p.224

Couleurs violet #874A9E (Hassidisme ch.15) :
16. **Rabbi Elimélekh de Lizhensk** — p.228
17. **Rabbi Na'hman de Breslev** — p.230

### Template 4 (Histoire Hassidique, Parole Vivante, Filiation Spirituelle)
Couleurs or #BE913D (Hassidisme ch.16) :
18. **Baal Shem Tov** — p.234
19. **Maguid de Mezeritch** — p.236
20. **Rabbi Lévi Yits'hak de Berditchev** — p.238
21. **Rabbi Shneur Zalman de Liadi** — p.240

## PROBLÈMES IDENTIFIÉS — À CORRIGER SUR TOUTES LES FICHES

### 1. Couleur du texte biographie — CRITIQUE
- **Actuel** : `#333333` (gris neutre)
- **Original PDF** : `#322114` (brun très foncé chaud)
- **Impact** : Le texte paraît délavé et grisâtre au lieu de riche et chaud
- **Concerne** : TOUTES les 21 fiches (fill="#333333" sur le texte courant)

### 2. Taille de police Template 3 — CRITIQUE  
- **Actuel** : biographie en `font-size="8"` avec interligne `dy="13.5"`
- **Devrait être** : `font-size="9.5"` avec interligne `dy="15.5"` (comme la page gauche)
- **Impact** : Police nettement plus petite que la page 1 (gauche) de chaque fiche
- **Concerne** : Fiches 1-17 (Template 3 rouge, vert, violet)
- **Note** : Template 4 (fiches 18-21) déjà en 9.5pt — correct

### 3. Occupation des lignes
- Certaines lignes de texte se terminent trop tôt, laissant du blanc inutile
- Exemple Berditchev : optimisé en remplissant mieux l'histoire hassidique
- **À appliquer** : sur toutes les fiches lors de la reprise

### 4. Titres de paragraphes
- Actuellement en couleur chapitre (rouge/vert/violet/or)
- Les pages gauche ont les titres en **noir** dans le PDF original
- **Note utilisateur** : "continuer comme ça pour l'instant" — harmoniser ultérieurement

### 5. Fond de page
- TOUJOURS ivoire `#FDF8F2` → `#FAF2E8` quelle que soit la couleur du chapitre
- Fiches vertes 11-14 corrigées en cours de session (étaient en vert pâle)
- Fiches 15+ créées directement avec fond ivoire

## PLAN DE REPRISE — PROCHAINE SESSION

### Approche décidée
Reprendre les fiches **une par une** en corrigeant :
- Police 9.5pt + interligne 15.5pt (Template 3)
- Couleur texte `#322114` au lieu de `#333333`
- Meilleure occupation des lignes
- Assortir chaque page droite à sa page gauche

### Ordre suggéré
Reprendre depuis la fiche 1 (Rif) jusqu'à la 21 (Zalman) avec les corrections,
puis continuer les fiches restantes jusqu'à la fin du livre.

### Fiches restantes après correction
- Après p.240 (Zalman) → suite du chapitre 16 et chapitres 17-19
- Phase 2 : remplacement photos (prompts Midjourney, checkpoint lignes 218-276)
- Phase 4 : export PDF CMJN final

## SPÉCIFICATIONS TECHNIQUES DE RÉFÉRENCE

### Couleurs par chapitre
| Chapitre | Couleur | Bandeau | Bandeau inf |
|----------|---------|---------|-------------|
| Ch.13 Codificateurs | Rouge | #8A3230 | #91413A |
| Ch.14 Kabbale Safed | Vert | #2C8B55 | #389560 |
| Ch.15 Hassidisme | Violet | #874A9E | #874A9E |
| Ch.16 Hassidisme | Or | #BE913D | #BE913D |

### Polices correctes
- Texte biographie : 9.5pt, interligne dy="15.5", fill="#322114"
- Titres sections : 8.5pt, fill=couleur chapitre, bold, letter-spacing 1.5
- Œuvres titres : 7.8pt → à augmenter proportionnellement
- Œuvres descriptions : 7.5pt → à augmenter proportionnellement  
- Saviez-vous : 7.5pt → à augmenter
- Héritage titres : 7.5pt bold
- Héritage descriptions : 7pt
- Filiation (Template 4) : 7pt (volontairement plus petit)
- Citations réflexion : 7.8pt italic
- Bandeau supérieur : 9-10pt
- Bandeau inférieur : 7.5pt
- Numéro page : 7pt

### Structure SVG
- Dimensions : 425×595
- Fond : gradient ivoire #FDF8F2 → #FAF2E8
- Cadre : double bordure + coins ornementaux
- Bandeau sup : y=13, h=26
- Bandeau inf : y=557, h=25

### Encadrés Template 3
- Œuvres : fill couleur pâle (rouge=#F2DDD8, vert=#DCEEE2, violet=#EDE0F2)
- Saviez-vous : fill=#FFF8E8 border=#C4973B (jaune doré, universel)
- Héritage : 2 colonnes, fill=none, border=couleur chapitre

### Encadrés Template 4
- Histoire hassidique : fill=#FDF5E6 border=or
- Parole vivante : fill=none border=or  
- Héritage : 2 colonnes comme Template 3
- Filiation : texte simple sans encadré

## FICHIERS DE SORTIE
Tous dans /mnt/user-data/outputs/ :
rif_page_droite.html, meiri_page_droite.html, rosh_page_droite.html,
tour_page_droite.html, abravanel_page_droite.html, sforno_page_droite.html,
karo_page_droite.html, rama_page_droite.html, maharal_page_droite.html,
kliyakar_page_droite.html, orhahaim_page_droite.html, ramak_page_droite.html,
arizal_page_droite.html, vital_page_droite.html, ramhal_page_droite.html,
elimelekh_page_droite.html, nahman_page_droite.html,
bst_page_droite_v2.html, maguid_page_droite.html,
berditchev_page_droite.html, zalman_page_droite.html
